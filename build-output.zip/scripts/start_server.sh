#!/bin/bash
sudo systemctl start tomcat
