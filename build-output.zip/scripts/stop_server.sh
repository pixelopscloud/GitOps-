#!/bin/bash
sudo systemctl stop tomcat
